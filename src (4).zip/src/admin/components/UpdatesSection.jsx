import UpdateTimeline from "./UpdateTimeline";
import UpdateCard from "./UpdateCard";

function UpdatesSection({ updatesData, setUpdatesData }) {
  const handleSaveUpdate = (id, updatedItem) => {
    setUpdatesData((prev) =>
      prev.map((item) => (item.id === id ? updatedItem : item))
    );
  };

  const handleDeleteUpdate = (id) => {
    setUpdatesData((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <section className="container-fluid px-0">
      <div className="row g-4">
        <div className="col-12 col-xl-4">
          <UpdateTimeline updatesData={updatesData} />
        </div>

        <div className="col-12 col-xl-8">
          <div className="row g-4">
            {updatesData.map((item) => (
              <div key={item.id} className="col-12">
                <UpdateCard
                  data={item}
                  onSave={(updatedItem) => handleSaveUpdate(item.id, updatedItem)}
                  onDelete={() => handleDeleteUpdate(item.id)}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default UpdatesSection;