import { useState } from "react";

function UpdateCard({ data, onSave, onDelete }) {
  const [isEditing, setIsEditing] = useState(false);

  const [title, setTitle] = useState(data.title);
  const [category, setCategory] = useState(data.category);
  const [date, setDate] = useState(data.date);
  const [time, setTime] = useState(data.time);
  const [text, setText] = useState(data.text);
  const [status, setStatus] = useState(data.status);

  const handleSave = () => {
    onSave({
      ...data,
      title,
      category,
      date,
      time,
      text,
      status,
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setTitle(data.title);
    setCategory(data.category);
    setDate(data.date);
    setTime(data.time);
    setText(data.text);
    setStatus(data.status);
    setIsEditing(false);
  };

  const statusBadgeClass =
    data.status === "current"
      ? "bg-primary-subtle text-primary"
      : data.status === "done"
      ? "bg-success-subtle text-success"
      : "bg-light text-dark";

  return (
    <section className="card border-0 shadow-sm h-100">
      <div className="card-body p-4">
        <div className="mb-3">
          {!isEditing ? (
            <div className="d-flex justify-content-between align-items-start gap-3">
              <div className="flex-grow-1">
                <h3 className="h6 fw-semibold mb-2">{data.title}</h3>

                <div className="d-flex flex-wrap align-items-center gap-2 small text-muted">
                  <span className="badge bg-secondary-subtle text-secondary">
                    {data.category}
                  </span>
                  <span>•</span>
                  <span>{data.date}</span>
                  <span>•</span>
                  <span>{data.time}</span>
                  <span>•</span>
                  <span className={`badge ${statusBadgeClass}`}>
                    {data.status}
                  </span>
                </div>
              </div>

              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-light btn-sm"
                  onClick={() => setIsEditing(true)}
                >
                  ✏️
                </button>
                <button
                  type="button"
                  className="btn btn-light btn-sm"
                  onClick={onDelete}
                >
                  🗑️
                </button>
              </div>
            </div>
          ) : (
            <div className="d-flex justify-content-between align-items-end flex-wrap gap-3">
              <div style={{ minWidth: "180px" }}>
                <label className="form-label text-muted small fw-semibold">
                  Status
                </label>
                <select
                  className="form-select"
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <option value="empty">Empty</option>
                  <option value="current">Current</option>
                  <option value="done">Done</option>
                </select>
              </div>

              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-outline-secondary btn-sm"
                  onClick={handleCancel}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-primary btn-sm"
                  onClick={handleSave}
                >
                  Save
                </button>
              </div>
            </div>
          )}
        </div>

        {!isEditing ? (
          <p className="text-muted mb-0">{data.text}</p>
        ) : (
          <div className="d-flex flex-column gap-3">
            <input
              className="form-control"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title"
            />

            <input
              className="form-control"
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="Category"
            />

            <div className="row g-3">
              <div className="col-12 col-md-6">
                <input
                  className="form-control"
                  type="text"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="Date"
                />
              </div>

              <div className="col-12 col-md-6">
                <input
                  className="form-control"
                  type="text"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  placeholder="Time"
                />
              </div>
            </div>

            <textarea
              className="form-control"
              rows="4"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Update text"
            />
          </div>
        )}
      </div>
    </section>
  );
}

export default UpdateCard;