import { useNavigate } from "react-router-dom";

function ClientCard({
  name,
  company,
  projects,
  status,
  updated,
  initials,
}) {
  const navigate = useNavigate();

  const handleClientClick = () => {
    if (name === "Sarah Johnson") {
      navigate("/projects");
    }
  };

  return (
    <div className="card border-0 shadow-sm h-100">
      <div className="card-body p-4 d-flex flex-column">

        {/* Header */}
        <div className="d-flex align-items-center mb-3">
          <div
            className="d-flex align-items-center justify-content-center rounded-circle bg-primary text-white fw-semibold me-3"
            style={{ width: "48px", height: "48px" }}
          >
            {initials}
          </div>

          <div>
            <h5
              className={`mb-1 fw-semibold ${
                name === "Sarah Johnson" ? "text-primary" : ""
              }`}
              style={{ cursor: name === "Sarah Johnson" ? "pointer" : "default" }}
              onClick={handleClientClick}
            >
              {name}
            </h5>

            <p className="mb-0 text-muted small">{company}</p>
          </div>
        </div>

        {/* Meta */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          <span className="badge bg-success-subtle text-success">
            {status}
          </span>

          <span className="text-muted small">
            {projects} projects
          </span>
        </div>

        <hr className="my-3" />

        {/* Footer */}
        <div className="d-flex justify-content-between align-items-center mt-auto">
          <span className="text-muted small">
            Updated {updated}
          </span>

          <div className="d-flex gap-2">
            <button className="btn btn-light btn-sm">👁</button>
            <button className="btn btn-light btn-sm">✏️</button>
            <button className="btn btn-light btn-sm">⚙️</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ClientCard;