const mockProjects = [
  {
    id: "alpha",
    name: "Project Alpha",
    clientName: "OWOW",
    contactPerson: "Michael Jackson",
    leader: "John Doe",
    phase: "Design Phase",
    status: "In Progress",
    progress: 68,

    monthlyBudget: {
      march: { total: 20000, spent: 12000 },
      april: { total: 25000, spent: 8000 },
    },

    budget: {
      total: 120000,
      spent: 74500,
      remaining: 45500,
    },

    deadline: "2026-06-30",

    documents: [
      {
        id: "alpha-doc-1",
        title: "Project Brief",
        type: "PDF",
        uploadedAt: "2026-03-15",
      },
    ],

    updates: [
      {
        id: "alpha-update-1",
        title: "Homepage UI approved",
        date: "2026-03-18",
        description: "Approved by client",
      },
    ],

    milestones: [
      {
        id: "alpha-milestone-1",
        title: "Wireframes Completed",
        status: "Completed",
        dueDate: "2026-03-10",
      },
    ],
  },
];

export default mockProjects;