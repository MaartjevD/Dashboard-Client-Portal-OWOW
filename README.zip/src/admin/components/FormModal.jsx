function FormModal({ show, title, children, onClose, onSave, saveLabel = "Save" }) {
  if (!show) return null;

  return (
    <>
      <div className="dashboard-modal-backdrop" onClick={onClose}></div>
      <div className="modal dashboard-modal fade show" tabIndex="-1" role="dialog">
        <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
          <div className="modal-content modal-dark">
            <div className="modal-header border-bottom-0 pb-0">
              <h5 className="modal-title">{title}</h5>
              <button type="button" className="btn-close" onClick={onClose}></button>
            </div>
            <div className="modal-body pt-3">{children}</div>
            <div className="modal-footer border-top-0 pt-0">
              <button type="button" className="btn btn-outline-light rounded-pill px-4" onClick={onClose}>
                Cancel
              </button>
              <button type="button" className="btn btn-light rounded-pill px-4" onClick={onSave}>
                {saveLabel}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default FormModal;