function ProjectActions({ onCreateProject }) {
  return (
    <div className="project-actions d-flex align-items-center gap-2 flex-wrap">
      <button
        type="button"
        className="project-actions__primary-btn"
        onClick={onCreateProject}
      >
        Create Project
      </button>
    </div>
  );
}

export default ProjectActions;