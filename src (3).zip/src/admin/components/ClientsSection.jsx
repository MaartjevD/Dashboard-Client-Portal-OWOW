import { useMemo, useState } from "react";
import ClientCard from "./ClientCard";

const initialClients = [
  {
    id: 1,
    name: "Sarah Johnson",
    company: "TechCorp Solutions",
    projects: 3,
    status: "Active",
    updated: "2 hours ago",
    initials: "SJ",
  },
  {
    id: 2,
    name: "Michael Chen",
    company: "Innovate Inc.",
    projects: 2,
    status: "Active",
    updated: "5 hours ago",
    initials: "MC",
  },
  {
    id: 3,
    name: "Emma Williams",
    company: "Bright Future",
    projects: 1,
    status: "Planning",
    updated: "1 day ago",
    initials: "EW",
  },
];

const emptyForm = {
  name: "",
  company: "",
  projects: 1,
  status: "Active",
};

function getInitials(name) {
  return name
    .trim()
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || "")
    .join("");
}

function ClientsSection() {
  const [clients, setClients] = useState(initialClients);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [formData, setFormData] = useState(emptyForm);

  const nextId = useMemo(() => {
    if (!clients.length) return 1;
    return Math.max(...clients.map((client) => client.id)) + 1;
  }, [clients]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: name === "projects" ? Number(value) : value,
    }));
  };

  const closeAddModal = () => {
    setShowAddModal(false);
    setFormData(emptyForm);
  };

  const closeEditModal = () => {
    setShowEditModal(false);
    setSelectedClient(null);
    setFormData(emptyForm);
  };

  const closeDeleteModal = () => {
    setShowDeleteModal(false);
    setSelectedClient(null);
  };

  const openAddModal = () => {
    setFormData(emptyForm);
    setShowAddModal(true);
  };

  const openEditModal = (client) => {
    setSelectedClient(client);
    setFormData({
      name: client.name,
      company: client.company,
      projects: client.projects,
      status: client.status,
    });
    setShowEditModal(true);
  };

  const openDeleteModal = (client) => {
    setSelectedClient(client);
    setShowDeleteModal(true);
  };

  const handleAddSubmit = (e) => {
    e.preventDefault();

    const trimmedName = formData.name.trim();
    const trimmedCompany = formData.company.trim();

    if (!trimmedName || !trimmedCompany) return;

    const newClient = {
      id: nextId,
      name: trimmedName,
      company: trimmedCompany,
      projects: formData.projects,
      status: formData.status,
      updated: "just now",
      initials: getInitials(trimmedName),
    };

    setClients((prev) => [newClient, ...prev]);
    closeAddModal();
  };

  const handleEditSubmit = (e) => {
    e.preventDefault();

    if (!selectedClient) return;

    const trimmedName = formData.name.trim();
    const trimmedCompany = formData.company.trim();

    if (!trimmedName || !trimmedCompany) return;

    setClients((prev) =>
      prev.map((client) =>
        client.id === selectedClient.id
          ? {
              ...client,
              name: trimmedName,
              company: trimmedCompany,
              projects: formData.projects,
              status: formData.status,
              updated: "just now",
              initials: getInitials(trimmedName),
            }
          : client
      )
    );

    closeEditModal();
  };

  const handleDeleteConfirm = () => {
    if (!selectedClient) return;

    setClients((prev) =>
      prev.filter((client) => client.id !== selectedClient.id)
    );

    closeDeleteModal();
  };

  return (
    <>
      <section className="clients-section">
        <div className="clients-header d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
          <div>
            <div className="clients-title">Clients</div>
            <p className="clients-subtitle mb-0">
              Overview of active client accounts and linked projects.
            </p>
          </div>

          <button type="button" className="clients-button" onClick={openAddModal}>
            Add Client
          </button>
        </div>

        <div className="row g-3">
          {clients.map((client) => (
            <div className="col-12 col-md-6 col-xl-4" key={client.id}>
              <ClientCard
                client={client}
                onEdit={openEditModal}
                onDelete={openDeleteModal}
              />
            </div>
          ))}
        </div>
      </section>

      {showAddModal && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <form onSubmit={handleAddSubmit}>
                  <div className="modal-header workspace-modal__header">
                    <h5 className="modal-title">Add Client</h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      aria-label="Close"
                      onClick={closeAddModal}
                    />
                  </div>

                  <div className="modal-body workspace-modal__body">
                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Client Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="form-control workspace-modal__input"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Enter client name"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Company
                      </label>
                      <input
                        type="text"
                        name="company"
                        className="form-control workspace-modal__input"
                        value={formData.company}
                        onChange={handleInputChange}
                        placeholder="Enter company name"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Projects
                      </label>
                      <input
                        type="number"
                        min="1"
                        name="projects"
                        className="form-control workspace-modal__input"
                        value={formData.projects}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div>
                      <label className="form-label workspace-modal__label">
                        Status
                      </label>
                      <select
                        name="status"
                        className="form-select workspace-modal__input"
                        value={formData.status}
                        onChange={handleInputChange}
                      >
                        <option value="Active">Active</option>
                        <option value="Planning">Planning</option>
                        <option value="Paused">Paused</option>
                      </select>
                    </div>
                  </div>

                  <div className="modal-footer workspace-modal__footer">
                    <button
                      type="button"
                      className="workspace-modal__secondary-btn"
                      onClick={closeAddModal}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="workspace-modal__primary-btn">
                      Save Client
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}

      {showEditModal && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <form onSubmit={handleEditSubmit}>
                  <div className="modal-header workspace-modal__header">
                    <h5 className="modal-title">Edit Client</h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      aria-label="Close"
                      onClick={closeEditModal}
                    />
                  </div>

                  <div className="modal-body workspace-modal__body">
                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Client Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="form-control workspace-modal__input"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Enter client name"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Company
                      </label>
                      <input
                        type="text"
                        name="company"
                        className="form-control workspace-modal__input"
                        value={formData.company}
                        onChange={handleInputChange}
                        placeholder="Enter company name"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Projects
                      </label>
                      <input
                        type="number"
                        min="1"
                        name="projects"
                        className="form-control workspace-modal__input"
                        value={formData.projects}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div>
                      <label className="form-label workspace-modal__label">
                        Status
                      </label>
                      <select
                        name="status"
                        className="form-select workspace-modal__input"
                        value={formData.status}
                        onChange={handleInputChange}
                      >
                        <option value="Active">Active</option>
                        <option value="Planning">Planning</option>
                        <option value="Paused">Paused</option>
                      </select>
                    </div>
                  </div>

                  <div className="modal-footer workspace-modal__footer">
                    <button
                      type="button"
                      className="workspace-modal__secondary-btn"
                      onClick={closeEditModal}
                    >
                      Cancel
                    </button>
                    <button type="submit" className="workspace-modal__primary-btn">
                      Update Client
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}

      {showDeleteModal && selectedClient && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <div className="modal-header workspace-modal__header">
                  <h5 className="modal-title">Delete Client</h5>
                  <button
                    type="button"
                    className="btn-close btn-close-white"
                    aria-label="Close"
                    onClick={closeDeleteModal}
                  />
                </div>

                <div className="modal-body workspace-modal__body">
                  <p className="text-white mb-2">
                    Are you sure you want to delete this client?
                  </p>
                  <p className="workspace-modal__delete-text mb-0">
                    <strong className="text-white">{selectedClient.name}</strong> from{" "}
                    {selectedClient.company} will be removed.
                  </p>
                </div>

                <div className="modal-footer workspace-modal__footer">
                  <button
                    type="button"
                    className="workspace-modal__secondary-btn"
                    onClick={closeDeleteModal}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="workspace-modal__danger-btn"
                    onClick={handleDeleteConfirm}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}
    </>
  );
}

export default ClientsSection;