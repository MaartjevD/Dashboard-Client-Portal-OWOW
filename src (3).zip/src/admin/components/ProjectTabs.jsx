function ProjectTabs({ activeTab, onTabChange }) {
  const tabs = [
    { key: "overview", label: "OVERVIEW", icon: "◎" },
    { key: "budget", label: "BUDGET", icon: "€" },
    { key: "updates", label: "UPDATES", icon: "🗓" },
    { key: "documents", label: "DOCUMENTEN", icon: "📄" },
  ];

  return (
    <div className="project-detail-tabs">
      <div className="d-flex align-items-center gap-2 gap-md-4 flex-wrap">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            type="button"
            className={`project-detail-tabs__item ${
              activeTab === tab.key ? "project-detail-tabs__item--active" : ""
            }`}
            onClick={() => onTabChange(tab.key)}
          >
            <span className="project-detail-tabs__icon">{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default ProjectTabs;