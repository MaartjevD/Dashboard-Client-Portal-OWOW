import { useNavigate } from "react-router-dom";

function ClientCard({ client, onEdit, onDelete }) {
  const navigate = useNavigate();

  const handleClientClick = () => {
    if (client.name === "Sarah Johnson") {
      navigate("/projects");
    }
  };

  return (
    <div className="client-card h-100 d-flex flex-column">
      <div className="client-card__header d-flex align-items-start gap-3 mb-3">
        <div className="client-card__avatar d-flex align-items-center justify-content-center">
          {client.initials}
        </div>

        <div className="client-card__identity flex-grow-1">
          <h3
            className={
              client.name === "Sarah Johnson"
                ? "client-card__name client-card__name--clickable mb-1"
                : "client-card__name mb-1"
            }
            onClick={handleClientClick}
            role={client.name === "Sarah Johnson" ? "button" : undefined}
          >
            {client.name}
          </h3>

          <p className="client-card__company mb-0">{client.company}</p>
        </div>
      </div>

      <div className="client-card__meta d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
        <span
          className={`client-card__status ${
            client.status === "Planning"
              ? "client-card__status--planning"
              : client.status === "Paused"
              ? "client-card__status--paused"
              : ""
          }`}
        >
          {client.status}
        </span>

        <span className="client-card__projects">{client.projects} projects</span>
      </div>

      <div className="client-card__divider" />

      <div className="client-card__footer d-flex align-items-center justify-content-between flex-wrap gap-3 mt-3 mt-auto">
        <span className="client-card__updated">Updated {client.updated}</span>

        <div className="client-card__actions d-flex align-items-center gap-2 flex-wrap">
          <button
            type="button"
            className="client-card__action-btn"
            onClick={handleClientClick}
          >
            View
          </button>

          <button
            type="button"
            className="client-card__action-btn"
            onClick={() => onEdit(client)}
          >
            Edit
          </button>

          <button
            type="button"
            className="client-card__action-btn client-card__action-btn--danger"
            onClick={() => onDelete(client)}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export default ClientCard;