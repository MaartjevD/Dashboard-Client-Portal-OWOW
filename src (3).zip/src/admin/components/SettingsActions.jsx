function SettingsActions({ onCancel, onSaveChanges }) {
  return (
    <div className="settings-actions d-flex align-items-center gap-2 flex-wrap">
      <button
        type="button"
        className="settings-actions__cancel-btn"
        onClick={onCancel}
      >
        Cancel
      </button>

      <button
        type="button"
        className="settings-actions__save-btn"
        onClick={onSaveChanges}
      >
        Save Changes
      </button>
    </div>
  );
}

export default SettingsActions;