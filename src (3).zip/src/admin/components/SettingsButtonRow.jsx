function SettingsButtonRow({ submitLabel = "Save Changes" }) {
  return (
    <div className="settings-button-row d-flex justify-content-end mt-4">
      <button type="submit" className="settings-button-row__submit-btn">
        {submitLabel}
      </button>
    </div>
  );
}

export default SettingsButtonRow;