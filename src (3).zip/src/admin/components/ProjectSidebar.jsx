import { Link, NavLink } from "react-router-dom";

function ProjectSidebar() {
  const navClass = ({ isActive }) =>
    isActive
      ? "project-sidebar__item text-decoration-none project-sidebar__item--active"
      : "project-sidebar__item text-decoration-none";

  return (
    <aside className="project-sidebar d-flex flex-column">
      <div className="project-sidebar__brand-wrap">
        <Link to="/workspace" className="project-sidebar__brand text-decoration-none">
          OWOW
        </Link>
      </div>

      <div className="project-sidebar__content">
        <Link to="/workspace" className="project-sidebar__back text-decoration-none">
          <span className="project-sidebar__back-icon">←</span>
          <span>Back to Client Page</span>
        </Link>

      </div>
    </aside>
  );
}

export default ProjectSidebar;