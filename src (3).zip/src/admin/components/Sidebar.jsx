import { NavLink } from "react-router-dom";

function Sidebar() {
  const getNavClass = ({ isActive }) =>
    isActive
      ? "sidebar__item text-decoration-none sidebar__item--active"
      : "sidebar__item text-decoration-none";

  return (
    <aside className="sidebar d-flex flex-column justify-content-between">
      <div>
        <div className="sidebar__logo">OWOW</div>

        <nav className="sidebar__nav nav flex-column">
          <NavLink to="/workspace" className={getNavClass}>
            Client Workspace
          </NavLink>

          <NavLink to="/settings" className={getNavClass}>
            Settings
          </NavLink>
        </nav>
      </div>

      <div className="sidebar__profile">
        <div className="sidebar__avatar d-flex align-items-center justify-content-center">
          M
        </div>

        <div>
          <div className="sidebar__name">Mostafa</div>
          <div className="sidebar__role">Administrator</div>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;