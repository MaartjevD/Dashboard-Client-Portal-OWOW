function Topbar() {
  return (
    <header className="topbar d-flex align-items-center justify-content-between">
      
      {/* LEFT - SEARCH */}
      <div className="topbar__left">
        <input
          type="text"
          placeholder="Search..."
          className="topbar__search form-control"
        />
      </div>

      {/* RIGHT - ACTIONS */}
      <div className="topbar__right d-flex align-items-center">
        <button
          type="button"
          className="topbar__lang btn btn-link text-decoration-none p-0"
        >
          EN / NL
        </button>

        <button type="button" className="topbar__icon-btn">
          🔔
        </button>

        <button type="button" className="topbar__icon-btn">
          ✉
        </button>

        <div className="topbar__avatar d-flex align-items-center justify-content-center">
          M
        </div>
      </div>
    </header>
  );
}

export default Topbar;