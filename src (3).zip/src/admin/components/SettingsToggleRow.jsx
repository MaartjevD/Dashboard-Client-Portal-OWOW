function SettingsToggleRow({
  title,
  description,
  name,
  checked,
  onChange,
}) {
  return (
    <div className="settings-toggle-card d-flex align-items-center justify-content-between gap-3">
      <div>
        <div className="settings-toggle-card__title">{title}</div>
        <div className="settings-toggle-card__description">{description}</div>
      </div>

      <label className="settings-toggle-card__switch">
        <input
          type="checkbox"
          name={name}
          checked={checked}
          onChange={onChange}
        />
        <span className="settings-toggle-card__slider"></span>
      </label>
    </div>
  );
}

export default SettingsToggleRow;