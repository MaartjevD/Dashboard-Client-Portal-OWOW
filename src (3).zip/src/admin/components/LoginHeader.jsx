function LoginHeader() {
  return (
    <div className="position-absolute top-0 start-0 p-3 p-md-4 z-3">
      <h1 className="m-0 fw-bold admin-brand-logo text-white">OWOW</h1>
    </div>
  );
}

export default LoginHeader;