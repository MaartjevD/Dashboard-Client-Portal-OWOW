function SettingsCard({
  title,
  subtitle,
  icon,
  iconClassName = "",
  children,
}) {
  return (
    <section className="settings-card-v2">
      <div className="settings-card-v2__header">
        <div className="d-flex align-items-start gap-3">
          {icon ? (
            <div className={iconClassName}>
              <span>{icon}</span>
            </div>
          ) : null}

          <div>
            <h2 className="settings-card-v2__title">{title}</h2>
            {subtitle ? (
              <p className="settings-card-v2__subtitle mb-0">{subtitle}</p>
            ) : null}
          </div>
        </div>
      </div>

      <div className="settings-card-v2__body">{children}</div>
    </section>
  );
}

export default SettingsCard;