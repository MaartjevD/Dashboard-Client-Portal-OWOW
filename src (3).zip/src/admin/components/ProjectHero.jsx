function ProjectHero({ title, subtitle }) {
  return (
    <div className="project-list-hero">
      <h1 className="project-list-hero__title">{title}</h1>
      <p className="project-list-hero__subtitle mb-0">{subtitle}</p>
    </div>
  );
}

export default ProjectHero;