import { useState } from "react";
import { useNavigate } from "react-router-dom";
import LoginInput from "./LoginInput";

function LoginForm() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/workspace");
  };

  return (
    <div className="card border-0 admin-auth-card shadow-sm">
      <div className="card-body p-4 p-md-5">
        <div className="mb-5">
          <h2 className="text-white fw-bold mb-2 admin-auth-title">
            Welcome to Dashboard
          </h2>
          <p className="text-secondary mb-0">Log in to continue</p>
        </div>

        <form onSubmit={handleSubmit}>
          <LoginInput
            id="email"
            label="Email"
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={setEmail}
          />

          <LoginInput
            id="password"
            label="Password"
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={setPassword}
          />

          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
            <div className="form-check m-0">
              <input
                id="rememberMe"
                className="form-check-input"
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <label
                className="form-check-label text-secondary small"
                htmlFor="rememberMe"
              >
                Remember me
              </label>
            </div>

            <button
              type="button"
              className="btn btn-link p-0 text-decoration-none text-secondary small"
            >
              Forgot password?
            </button>
          </div>

          <button type="submit" className="btn btn-light w-100 py-3 fw-semibold">
            Login
          </button>
        </form>

        <p className="text-center text-secondary mt-4 mb-0 small">
          Don&apos;t have an account?{" "}
          <button
            type="button"
            className="btn btn-link p-0 text-white text-decoration-none fw-semibold align-baseline"
          >
            Sign up
          </button>
        </p>
      </div>
    </div>
  );
}

export default LoginForm;