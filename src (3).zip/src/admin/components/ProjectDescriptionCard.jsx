function ProjectDescription({ project, activeTab }) {
  const contentMap = {
    overview: {
      title: "Project Description",
      description:
        "This section gives a high-level overview of the project scope, goals, and current direction.",
      blocks: [
        {
          heading: "Objective",
          text: project.objective,
        },
        {
          heading: "Current Focus",
          text: "The team is currently refining dashboard components, validating the tab structure, and aligning the design with the client portal experience.",
        },
        {
          heading: "Next Step",
          text: project.nextStep,
        },
      ],
    },
    budget: {
      title: "Budget Overview",
      description:
        "A summary of the current budget direction and allocation priorities.",
      blocks: [
        {
          heading: "Budget Strategy",
          text: "The project uses a monthly budget view so the team can easily track spending, remaining budget, and rollover conditions.",
        },
        {
          heading: "Current Observation",
          text: "The current phase stays within the allocated budget and allows room for design refinement before development handoff.",
        },
        {
          heading: "Next Financial Check",
          text: "Review budget usage after the next client feedback round and update the monthly tracking view.",
        },
      ],
    },
    documents: {
      title: "Document Overview",
      description:
        "Key files and references used to support the project flow.",
      blocks: [
        {
          heading: "Main References",
          text: "The project currently relies on design files, requirement notes, and shared reference assets to keep decisions aligned.",
        },
        {
          heading: "Visibility",
          text: "Documents should remain easy to access, clearly grouped, and visible based on the user role inside the portal.",
        },
        {
          heading: "Next Step",
          text: "Prepare a structured document area where key files can be previewed and downloaded.",
        },
      ],
    },
    updates: {
      title: "Updates & Milestones",
      description:
        "Recent progress, decisions, and upcoming review points for the project.",
      blocks: [
        {
          heading: "Latest Progress",
          text: "The dashboard structure is becoming more stable, and the navigation pattern has been clarified for the next UI iteration.",
        },
        {
          heading: "Milestone",
          text: "Wireframes and first layout versions are completed and ready for alignment with stakeholders.",
        },
        {
          heading: "Upcoming Review",
          text: "The next important step is validating the design direction together with the client and internal team.",
        },
      ],
    },
  };

  const currentContent = contentMap[activeTab];

  return (
    <section className="project-description">
      <div className="project-description__header">
        <h2 className="project-description__title">{currentContent.title}</h2>
        <p className="project-description__subtitle mb-0">
          {currentContent.description}
        </p>
      </div>

      <div className="project-description__body">
        {currentContent.blocks.map((block) => (
          <div className="project-description__block" key={block.heading}>
            <h3 className="project-description__block-title">{block.heading}</h3>
            <p className="project-description__block-text mb-0">{block.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default ProjectDescription;