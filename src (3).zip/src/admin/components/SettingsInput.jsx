function SettingsInput({
  label,
  name,
  value,
  onChange,
  placeholder = "",
  type = "text",
}) {
  return (
    <div className="settings-input-v2">
      <label className="settings-input-v2__label">{label}</label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="settings-input-v2__control form-control"
      />
    </div>
  );
}

export default SettingsInput;