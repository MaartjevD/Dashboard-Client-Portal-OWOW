function ProjectCard({ project }) {
  return (
    <div className="project-list-card h-100">
      <div className="d-flex align-items-start justify-content-between gap-3 mb-3">
        <div>
          <h2 className="project-list-card__title mb-2">{project.title}</h2>

          <span
            className={`project-list-card__status ${
              project.statusVariant === "progress"
                ? "project-list-card__status--progress"
                : "project-list-card__status--active"
            }`}
          >
            {project.status}
          </span>
        </div>

        <button type="button" className="project-list-card__menu-btn">
          ⋮
        </button>
      </div>

      <div className="mb-3">
        <div className="d-flex align-items-center justify-content-between mb-2">
          <span className="project-list-card__meta-label">Progress</span>
          <span className="project-list-card__progress-value">{project.progress}%</span>
        </div>

        <div className="project-list-card__progress-bar">
          <div
            className="project-list-card__progress-fill"
            style={{ width: `${project.progress}%` }}
          />
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-6">
          <div className="project-list-card__info-label">Start Date</div>
          <div className="project-list-card__info-value">{project.startDate}</div>
        </div>

        <div className="col-6">
          <div className="project-list-card__info-label">End Date</div>
          <div className="project-list-card__info-value">{project.endDate}</div>
        </div>
      </div>

      <div className="project-list-card__divider" />

      <div className="d-flex align-items-center justify-content-between gap-3 pt-3">
        <div className="d-flex align-items-center">
          {project.members.map((member, index) => (
            <div
              className="project-list-card__avatar"
              key={member + index}
              style={{ marginLeft: index === 0 ? 0 : "-8px" }}
            >
              {member}
            </div>
          ))}
        </div>

        <span className="project-list-card__updated">{project.updated}</span>
      </div>
    </div>
  );
}

export default ProjectCard;