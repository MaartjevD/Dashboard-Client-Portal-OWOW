function LoginInput({
  label,
  type = "text",
  placeholder,
  value,
  onChange,
  id,
}) {
  return (
    <div className="mb-4">
      <label htmlFor={id} className="form-label text-secondary small mb-2">
        {label}
      </label>

      <input
        id={id}
        type={type}
        className="form-control admin-auth-input"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export default LoginInput;