import LoginHeader from "../components/LoginHeader";
import LoginForm from "../components/LoginForm";

function LoginPage() {
  return (
    <div className="admin-auth-page min-vh-100 text-light position-relative">
      <LoginHeader />

      <div className="container-fluid min-vh-100">
        <div className="row min-vh-100 justify-content-center align-items-center px-3 px-md-4 px-lg-5">
          <div className="col-12 col-sm-10 col-md-8 col-lg-5 col-xl-4">
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;