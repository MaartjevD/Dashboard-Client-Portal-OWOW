import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import ClientsSection from "../components/ClientsSection";

function ClientWorkspacePage() {
  return (
    <div className="workspace-page">
      <div className="container-fluid px-0">
        <div className="row g-0 min-vh-100">
          <div className="col-12 col-lg-auto">
            <Sidebar />
          </div>

          <div className="col">
            <div className="workspace-main">
              <Topbar />

              <main className="workspace-content">
                <div className="mb-4">
                  <h1 className="workspace-title mb-2">Client Workspace</h1>
                  <p className="workspace-subtitle mb-0">
                    Manage your clients and projects in one place.
                  </p>
                </div>

                <ClientsSection />
              </main>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ClientWorkspacePage;