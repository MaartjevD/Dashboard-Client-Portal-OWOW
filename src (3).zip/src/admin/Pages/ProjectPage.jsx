import { useMemo, useState } from "react";
import Topbar from "../components/Topbar";
import ProjectSidebar from "../components/ProjectSidebar";
import ProjectHero from "../components/ProjectHero";
import ProjectActions from "../components/ProjectActions";
import ProjectCard from "../components/ProjectCard";

const initialProjects = [
  {
    id: 1,
    title: "Website Redesign",
    status: "Active",
    progress: 65,
    startDate: "Jan 15, 2026",
    endDate: "Apr 30, 2026",
    members: ["ML", "AE", "TS"],
    updated: "Updated 2 hours ago",
    statusVariant: "active",
  },
  {
    id: 2,
    title: "Mobile Banking App",
    status: "Active",
    progress: 42,
    startDate: "Feb 1, 2026",
    endDate: "Jun 15, 2026",
    members: ["CD", "AE", "MA"],
    updated: "Updated 5 hours ago",
    statusVariant: "active",
  },
  {
    id: 3,
    title: "Brand Strategy",
    status: "In Progress",
    progress: 15,
    startDate: "Mar 1, 2026",
    endDate: "May 31, 2026",
    members: ["CD", "KE", "JA"],
    updated: "Updated 1 day ago",
    statusVariant: "progress",
  },
];

const emptyForm = {
  title: "",
  status: "Active",
  progress: 0,
  startDate: "",
  endDate: "",
};

function ProjectPage() {
  const [projects, setProjects] = useState(initialProjects);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [formData, setFormData] = useState(emptyForm);

  const nextId = useMemo(() => {
    if (!projects.length) return 1;
    return Math.max(...projects.map((project) => project.id)) + 1;
  }, [projects]);

  const handleOpenCreateModal = () => {
    setFormData(emptyForm);
    setShowCreateModal(true);
  };

  const handleCloseCreateModal = () => {
    setShowCreateModal(false);
    setFormData(emptyForm);
  };

  const handleOpenEditModal = (project) => {
    setSelectedProject(project);
    setFormData({
      title: project.title,
      status: project.status,
      progress: project.progress,
      startDate: convertDisplayDateToInput(project.startDate),
      endDate: convertDisplayDateToInput(project.endDate),
    });
    setShowEditModal(true);
  };

  const handleCloseEditModal = () => {
    setSelectedProject(null);
    setShowEditModal(false);
    setFormData(emptyForm);
  };

  const handleOpenDeleteModal = (project) => {
    setSelectedProject(project);
    setShowDeleteModal(true);
  };

  const handleCloseDeleteModal = () => {
    setSelectedProject(null);
    setShowDeleteModal(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: name === "progress" ? Number(value) : value,
    }));
  };

  const formatDate = (dateValue) => {
    if (!dateValue) return "";

    const date = new Date(dateValue);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const convertDisplayDateToInput = (displayDate) => {
    const date = new Date(displayDate);
    if (Number.isNaN(date.getTime())) return "";

    const year = date.getFullYear();
    const month = `${date.getMonth() + 1}`.padStart(2, "0");
    const day = `${date.getDate()}`.padStart(2, "0");

    return `${year}-${month}-${day}`;
  };

  const getStatusVariant = (status) => {
    if (status === "In Progress") return "progress";
    return "active";
  };

  const handleCreateProject = (e) => {
    e.preventDefault();

    const trimmedTitle = formData.title.trim();

    if (!trimmedTitle || !formData.startDate || !formData.endDate) return;

    const newProject = {
      id: nextId,
      title: trimmedTitle,
      status: formData.status,
      progress: formData.progress,
      startDate: formatDate(formData.startDate),
      endDate: formatDate(formData.endDate),
      members: ["NP", "UI", "UX"],
      updated: "Updated just now",
      statusVariant: getStatusVariant(formData.status),
    };

    setProjects((prev) => [newProject, ...prev]);
    handleCloseCreateModal();
  };

  const handleEditProject = (e) => {
    e.preventDefault();

    if (!selectedProject) return;

    const trimmedTitle = formData.title.trim();

    if (!trimmedTitle || !formData.startDate || !formData.endDate) return;

    setProjects((prev) =>
      prev.map((project) =>
        project.id === selectedProject.id
          ? {
              ...project,
              title: trimmedTitle,
              status: formData.status,
              progress: formData.progress,
              startDate: formatDate(formData.startDate),
              endDate: formatDate(formData.endDate),
              updated: "Updated just now",
              statusVariant: getStatusVariant(formData.status),
            }
          : project
      )
    );

    handleCloseEditModal();
  };

  const handleDeleteProject = () => {
    if (!selectedProject) return;

    setProjects((prev) =>
      prev.filter((project) => project.id !== selectedProject.id)
    );

    handleCloseDeleteModal();
  };

  return (
    <div className="workspace-page">
      <div className="container-fluid px-0">
        <div className="row g-0 min-vh-100">
          <div className="col-12 col-lg-auto">
            <ProjectSidebar />
          </div>

          <div className="col">
            <div className="workspace-main">
              <Topbar />

              <main className="workspace-content project-page-content">
                <div className="d-flex flex-column flex-xl-row align-items-xl-start justify-content-between gap-3 mb-4">
                  <ProjectHero
                    title="Projects"
                    subtitle="Manage and track all your projects"
                  />

                  <ProjectActions onCreateProject={handleOpenCreateModal} />
                </div>

                <div className="row g-3">
                  {projects.map((project) => (
                    <div className="col-12 col-lg-6" key={project.id}>
                      <ProjectCard
                        project={project}
                        onEditClick={handleOpenEditModal}
                        onDeleteClick={handleOpenDeleteModal}
                      />
                    </div>
                  ))}
                </div>
              </main>
            </div>
          </div>
        </div>
      </div>

      {showCreateModal && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <form onSubmit={handleCreateProject}>
                  <div className="modal-header workspace-modal__header">
                    <h5 className="modal-title">Create Project</h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      aria-label="Close"
                      onClick={handleCloseCreateModal}
                    />
                  </div>

                  <div className="modal-body workspace-modal__body">
                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Project Title
                      </label>
                      <input
                        type="text"
                        name="title"
                        className="form-control workspace-modal__input"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter project title"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Status
                      </label>
                      <select
                        name="status"
                        className="form-select workspace-modal__input"
                        value={formData.status}
                        onChange={handleChange}
                      >
                        <option value="Active">Active</option>
                        <option value="In Progress">In Progress</option>
                      </select>
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Progress
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        name="progress"
                        className="form-control workspace-modal__input"
                        value={formData.progress}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="row g-3">
                      <div className="col-12 col-md-6">
                        <label className="form-label workspace-modal__label">
                          Start Date
                        </label>
                        <input
                          type="date"
                          name="startDate"
                          className="form-control workspace-modal__input"
                          value={formData.startDate}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="col-12 col-md-6">
                        <label className="form-label workspace-modal__label">
                          End Date
                        </label>
                        <input
                          type="date"
                          name="endDate"
                          className="form-control workspace-modal__input"
                          value={formData.endDate}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="modal-footer workspace-modal__footer">
                    <button
                      type="button"
                      className="workspace-modal__secondary-btn"
                      onClick={handleCloseCreateModal}
                    >
                      Cancel
                    </button>

                    <button
                      type="submit"
                      className="workspace-modal__primary-btn"
                    >
                      Create Project
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}

      {showEditModal && selectedProject && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <form onSubmit={handleEditProject}>
                  <div className="modal-header workspace-modal__header">
                    <h5 className="modal-title">Edit Project</h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      aria-label="Close"
                      onClick={handleCloseEditModal}
                    />
                  </div>

                  <div className="modal-body workspace-modal__body">
                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Project Title
                      </label>
                      <input
                        type="text"
                        name="title"
                        className="form-control workspace-modal__input"
                        value={formData.title}
                        onChange={handleChange}
                        placeholder="Enter project title"
                      />
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Status
                      </label>
                      <select
                        name="status"
                        className="form-select workspace-modal__input"
                        value={formData.status}
                        onChange={handleChange}
                      >
                        <option value="Active">Active</option>
                        <option value="In Progress">In Progress</option>
                      </select>
                    </div>

                    <div className="mb-3">
                      <label className="form-label workspace-modal__label">
                        Progress
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        name="progress"
                        className="form-control workspace-modal__input"
                        value={formData.progress}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="row g-3">
                      <div className="col-12 col-md-6">
                        <label className="form-label workspace-modal__label">
                          Start Date
                        </label>
                        <input
                          type="date"
                          name="startDate"
                          className="form-control workspace-modal__input"
                          value={formData.startDate}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="col-12 col-md-6">
                        <label className="form-label workspace-modal__label">
                          End Date
                        </label>
                        <input
                          type="date"
                          name="endDate"
                          className="form-control workspace-modal__input"
                          value={formData.endDate}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="modal-footer workspace-modal__footer">
                    <button
                      type="button"
                      className="workspace-modal__secondary-btn"
                      onClick={handleCloseEditModal}
                    >
                      Cancel
                    </button>

                    <button
                      type="submit"
                      className="workspace-modal__primary-btn"
                    >
                      Save Changes
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}

      {showDeleteModal && selectedProject && (
        <>
          <div className="modal fade show d-block" tabIndex="-1" role="dialog">
            <div className="modal-dialog modal-dialog-centered">
              <div className="modal-content workspace-modal">
                <div className="modal-header workspace-modal__header">
                  <h5 className="modal-title">Delete Project</h5>
                  <button
                    type="button"
                    className="btn-close btn-close-white"
                    aria-label="Close"
                    onClick={handleCloseDeleteModal}
                  />
                </div>

                <div className="modal-body workspace-modal__body">
                  <p className="text-white mb-2">
                    Are you sure you want to delete this project?
                  </p>
                  <p className="workspace-modal__delete-text mb-0">
                    <strong className="text-white">{selectedProject.title}</strong>{" "}
                    will be removed from the project list.
                  </p>
                </div>

                <div className="modal-footer workspace-modal__footer">
                  <button
                    type="button"
                    className="workspace-modal__secondary-btn"
                    onClick={handleCloseDeleteModal}
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    className="workspace-modal__danger-btn"
                    onClick={handleDeleteProject}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="modal-backdrop fade show workspace-modal__backdrop" />
        </>
      )}
    </div>
  );
}

export default ProjectPage;