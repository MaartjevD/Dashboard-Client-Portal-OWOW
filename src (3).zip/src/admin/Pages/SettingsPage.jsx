import { useState } from "react";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import SettingsActions from "../components/SettingsActions";
import SettingsCard from "../components/SettingsCard";
import SettingsInput from "../components/SettingsInput";
import SettingsToggleRow from "../components/SettingsToggleRow";

function SettingsPage() {
  const [accountSettings, setAccountSettings] = useState({
    fullName: "Sarah Sanders",
    email: "Sarah.S@owow.com",
    role: "Administrator",
    department: "Project Management",
  });

  const [securitySettings, setSecuritySettings] = useState({
    currentPassword: "••••••••••",
    newPassword: "",
    confirmPassword: "",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    projectUpdates: true,
    pushNotifications: true,
    budgetAlerts: true,
  });

  const [regionSettings, setRegionSettings] = useState({
    language: "",
    timezone: "",
  });

  const handleAccountChange = (e) => {
    const { name, value } = e.target;
    setAccountSettings((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSecurityChange = (e) => {
    const { name, value } = e.target;
    setSecuritySettings((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleRegionChange = (e) => {
    const { name, value } = e.target;
    setRegionSettings((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotificationSettings((prev) => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleCancel = () => {
    console.log("Cancel clicked");
  };

  const handleSaveChanges = () => {
    console.log("Save changes clicked", {
      accountSettings,
      securitySettings,
      notificationSettings,
      regionSettings,
    });
  };

  return (
    <div className="workspace-page">
      <div className="container-fluid px-0">
        <div className="row g-0 min-vh-100">
          <div className="col-12 col-lg-auto">
            <Sidebar />
          </div>

          <div className="col">
            <div className="workspace-main">
              <Topbar />

              <main className="workspace-content settings-layout">
                <div className="settings-page-header">
                  <div>
                    <h1 className="settings-page-title">Settings</h1>
                    <p className="settings-page-subtitle">
                      Manage system preferences and configurations
                    </p>
                  </div>

                  <SettingsActions
                    onCancel={handleCancel}
                    onSaveChanges={handleSaveChanges}
                  />
                </div>

                <div className="row g-3">
                  <div className="col-12 col-xl-6">
                    <SettingsCard
                      title="Account Settings"
                      icon="👤"
                      iconClassName="settings-card__icon settings-card__icon--blue"
                    >
                      <div className="row g-3">
                        <div className="col-12">
                          <SettingsInput
                            label="Full Name"
                            name="fullName"
                            value={accountSettings.fullName}
                            onChange={handleAccountChange}
                            placeholder="Enter full name"
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="Email Address"
                            name="email"
                            type="email"
                            value={accountSettings.email}
                            onChange={handleAccountChange}
                            placeholder="Enter email address"
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="Role"
                            name="role"
                            value={accountSettings.role}
                            onChange={handleAccountChange}
                            placeholder="Enter role"
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="Department"
                            name="department"
                            value={accountSettings.department}
                            onChange={handleAccountChange}
                            placeholder="Enter department"
                          />
                        </div>
                      </div>
                    </SettingsCard>
                  </div>

                  <div className="col-12 col-xl-6">
                    <SettingsCard
                      title="Security Settings"
                      icon="🛡"
                      iconClassName="settings-card__icon settings-card__icon--green"
                    >
                      <div className="row g-3">
                        <div className="col-12">
                          <SettingsInput
                            label="Current Password"
                            name="currentPassword"
                            type="text"
                            value={securitySettings.currentPassword}
                            onChange={handleSecurityChange}
                            placeholder="Enter current password"
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="New Password"
                            name="newPassword"
                            type="password"
                            value={securitySettings.newPassword}
                            onChange={handleSecurityChange}
                            placeholder="Enter new password"
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="Confirm Password"
                            name="confirmPassword"
                            type="password"
                            value={securitySettings.confirmPassword}
                            onChange={handleSecurityChange}
                            placeholder="Confirm new password"
                          />
                        </div>
                      </div>
                    </SettingsCard>
                  </div>

                  <div className="col-12">
                    <SettingsCard
                      title="Notification Settings"
                      subtitle="Manage how you receive notifications"
                      icon="🔔"
                      iconClassName="settings-card__icon settings-card__icon--yellow"
                    >
                      <div className="row g-3">
                        <div className="col-12 col-md-6">
                          <SettingsToggleRow
                            title="Email Notifications"
                            description="Receive updates via email"
                            name="emailNotifications"
                            checked={notificationSettings.emailNotifications}
                            onChange={handleNotificationChange}
                          />
                        </div>

                        <div className="col-12 col-md-6">
                          <SettingsToggleRow
                            title="Project Updates"
                            description="Notify on project changes"
                            name="projectUpdates"
                            checked={notificationSettings.projectUpdates}
                            onChange={handleNotificationChange}
                          />
                        </div>

                        <div className="col-12 col-md-6">
                          <SettingsToggleRow
                            title="Push Notifications"
                            description="Browser push notifications"
                            name="pushNotifications"
                            checked={notificationSettings.pushNotifications}
                            onChange={handleNotificationChange}
                          />
                        </div>

                        <div className="col-12 col-md-6">
                          <SettingsToggleRow
                            title="Budget Alerts"
                            description="Notify on budget thresholds"
                            name="budgetAlerts"
                            checked={notificationSettings.budgetAlerts}
                            onChange={handleNotificationChange}
                          />
                        </div>
                      </div>
                    </SettingsCard>
                  </div>

                  <div className="col-12 col-xl-6">
                    <SettingsCard
                      title="Language & Region"
                      icon="🌐"
                      iconClassName="settings-card__icon settings-card__icon--blue"
                    >
                      <div className="row g-3">
                        <div className="col-12">
                          <SettingsInput
                            label="Language"
                            name="language"
                            value={regionSettings.language}
                            onChange={handleRegionChange}
                            placeholder=""
                          />
                        </div>

                        <div className="col-12">
                          <SettingsInput
                            label="Timezone"
                            name="timezone"
                            value={regionSettings.timezone}
                            onChange={handleRegionChange}
                            placeholder=""
                          />
                        </div>
                      </div>
                    </SettingsCard>
                  </div>

                  <div className="col-12 col-xl-6">
                    <SettingsCard
                      title="Data Management"
                      icon="🗄"
                      iconClassName="settings-card__icon settings-card__icon--green"
                    >
                      <div className="d-flex flex-column gap-3">
                        <button type="button" className="settings-data-btn">
                          Export All Data
                        </button>

                        <button type="button" className="settings-data-btn">
                          Import Data
                        </button>

                        <button type="button" className="settings-data-btn">
                          Clear Cache
                        </button>
                      </div>
                    </SettingsCard>
                  </div>
                </div>
              </main>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SettingsPage;