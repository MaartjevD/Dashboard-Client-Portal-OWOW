function FormModal({
  show,
  title,
  children,
  onClose,
  onSave,
  saveLabel = "Save",
}) {
  if (!show) return null;

  return (
    <>
      <div className="modal-backdrop fade show"></div>

      <div
        className="modal fade show d-block"
        tabIndex="-1"
        role="dialog"
        aria-modal="true"
      >
        <div className="modal-dialog modal-dialog-centered modal-lg" role="document">
          <div className="modal-content bg-dark text-white border-secondary">
            <div className="modal-header border-secondary">
              <h5 className="modal-title">{title}</h5>
              <button
                type="button"
                className="btn-close btn-close-white"
                onClick={onClose}
                aria-label="Close"
              ></button>
            </div>

            <div className="modal-body">{children}</div>

            <div className="modal-footer border-secondary">
              <button
                type="button"
                className="btn btn-outline-light"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-light"
                onClick={onSave}
              >
                {saveLabel}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default FormModal;