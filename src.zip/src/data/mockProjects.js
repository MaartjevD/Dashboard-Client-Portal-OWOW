const mockProjects = [
  {
    id: "alpha",
    name: "OWOW Client Portal",
    company: "OWOW",
    clientName: "OWOW",
    contactPerson: "Michael Jackson",
    leader: "John Doe",
    phone: "+31 6 1234 5678",
    email: "michael@owow.io",
    location: "Eindhoven, Netherlands",
    phase: "Design",
    currentPhase: "Design",
    status: "In Progress",
    progress: 68,
    description:
      "A client portal dashboard for OWOW where clients can track project progress, documents, budget, and latest updates in one place.",
    startDate: "2026-02-10",
    targetEndDate: "2026-06-30",
    deadline: "2026-06-30",
    updatedAt: "2 hours ago",
    team: ["John Doe", "Emma Stone", "Alex Brown"],

    budgetData: {
      current: {
        id: "alpha-budget-current",
        month: "April 2026",
        budget: 25000,
        spent: 8000,
      },
      previous: [
        {
          id: "alpha-budget-1",
          month: "March 2026",
          budget: 20000,
          spent: 12000,
        },
        {
          id: "alpha-budget-2",
          month: "February 2026",
          budget: 18000,
          spent: 9500,
        },
      ],
    },

    documents: [
      {
        id: "alpha-doc-1",
        title: "Project Brief",
        description: "Main brief with project goals, scope, and deliverables.",
        linkLabel: "Brief Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Approved",
        color: "blue",
        type: "PDF",
        uploadedAt: "2026-03-15",
      },
      {
        id: "alpha-doc-2",
        title: "Design System",
        description: "Shared components, layout rules, and visual guidelines.",
        linkLabel: "Design Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Ongoing",
        color: "orange",
        type: "FIGMA",
        uploadedAt: "2026-03-18",
      },
    ],

    updates: [
      {
        id: "alpha-update-1",
        title: "Homepage UI approved",
        category: "Design",
        date: "March 18, 2026",
        time: "10:30 AM",
        text: "The homepage UI direction was approved by the client and can move into the next design iteration.",
        status: "current",
        description: "Approved by client",
      },
      {
        id: "alpha-update-2",
        title: "Wireframe review completed",
        category: "UX Review",
        date: "March 14, 2026",
        time: "03:00 PM",
        text: "Wireframes were reviewed internally and feedback has been applied to the main dashboard screens.",
        status: "done",
      },
    ],

    milestones: [
      {
        id: "alpha-milestone-1",
        title: "Wireframes Completed",
        status: "Completed",
        dueDate: "2026-03-10",
      },
    ],
  },

  {
    id: "beta",
    name: "Mobile Banking App",
    company: "ACME Corporation",
    clientName: "ACME Corporation",
    contactPerson: "Jan Jansen",
    leader: "Sarah Lee",
    phone: "+31 6 8765 4321",
    email: "jan.j@acmecorp.com",
    location: "Amsterdam, Netherlands",
    phase: "Development",
    currentPhase: "Development",
    status: "Active",
    progress: 33,
    description:
      "A banking app dashboard project focused on creating secure, user-friendly mobile experiences with clear flows and scalable design patterns.",
    startDate: "2026-02-28",
    targetEndDate: "2026-11-01",
    deadline: "2026-11-01",
    updatedAt: "5 hours ago",
    team: ["Sarah Lee", "Tom Smith", "Nina Patel"],

    budgetData: {
      current: {
        id: "beta-budget-current",
        month: "March 2026",
        budget: 2500,
        spent: 940,
      },
      previous: [
        {
          id: "beta-budget-1",
          month: "February 2026",
          budget: 3000,
          spent: 2920,
        },
        {
          id: "beta-budget-2",
          month: "January 2026",
          budget: 1200,
          spent: 1250,
        },
      ],
    },

    documents: [
      {
        id: "beta-doc-1",
        title: "Figma Design Files",
        description: "Live design files and interactive prototypes.",
        linkLabel: "Jira Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Ongoing",
        color: "blue",
      },
      {
        id: "beta-doc-2",
        title: "Design System Documentation",
        description: "UI components and design patterns library.",
        linkLabel: "Jira Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Ongoing",
        color: "orange",
      },
      {
        id: "beta-doc-3",
        title: "API Notes",
        description: "Key API endpoints and integration constraints.",
        linkLabel: "API Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Draft",
        color: "yellow",
      },
    ],

    updates: [
      {
        id: "beta-update-1",
        title: "Sprint Planning Meeting Scheduled",
        category: "Mobile App Development",
        date: "March 14, 2026",
        time: "4:15 PM",
        text: "Next sprint planning meeting set for March 18th at 10:00 AM. Agenda includes development roadmap review.",
        status: "empty",
      },
      {
        id: "beta-update-2",
        title: "Technical Documentation Updated",
        category: "E-commerce Platform",
        date: "March 13, 2026",
        time: "11:20 AM",
        text: "System architecture document updated with latest API specifications and database schema designs.",
        status: "current",
      },
      {
        id: "beta-update-3",
        title: "Development Environment Ready",
        category: "Website Redesign",
        date: "March 12, 2026",
        time: "9:45 AM",
        text: "All development environments configured. Team members have access to staging servers and repositories.",
        status: "done",
      },
    ],

    milestones: [
      {
        id: "beta-milestone-1",
        title: "API Architecture Approved",
        status: "Completed",
        dueDate: "2026-03-05",
      },
    ],
  },

  {
    id: "gamma",
    name: "Brand Strategy",
    company: "Nova Studio",
    clientName: "Nova Studio",
    contactPerson: "Laura Adams",
    leader: "Kevin Tran",
    phone: "+31 6 2222 3333",
    email: "laura@novastudio.com",
    location: "Rotterdam, Netherlands",
    phase: "Kickoff",
    currentPhase: "Kickoff",
    status: "Planned",
    progress: 15,
    description:
      "A brand strategy and digital direction project focused on aligning messaging, visuals, and stakeholder expectations for the new launch.",
    startDate: "2026-03-01",
    targetEndDate: "2026-05-31",
    deadline: "2026-05-31",
    updatedAt: "1 day ago",
    team: ["Kevin Tran", "Julia Adams", "Chris Doe"],

    budgetData: {
      current: {
        id: "gamma-budget-current",
        month: "April 2026",
        budget: 5000,
        spent: 1200,
      },
      previous: [
        {
          id: "gamma-budget-1",
          month: "March 2026",
          budget: 4200,
          spent: 2100,
        },
      ],
    },

    documents: [
      {
        id: "gamma-doc-1",
        title: "Research Summary",
        description: "Initial market and competitor research summary.",
        linkLabel: "Research Link",
        jiraUrl: "https://jira.atlassian.com",
        status: "Review",
        color: "green",
      },
    ],

    updates: [
      {
        id: "gamma-update-1",
        title: "Kickoff workshop prepared",
        category: "Strategy",
        date: "March 10, 2026",
        time: "01:00 PM",
        text: "Workshop agenda and first stakeholder alignment deck are ready.",
        status: "done",
      },
    ],

    milestones: [
      {
        id: "gamma-milestone-1",
        title: "Kickoff Session",
        status: "Planned",
        dueDate: "2026-03-12",
      },
    ],
  },
];

export const defaultProjectId = mockProjects[0].id;

export function getProjectById(projectId) {
  return mockProjects.find((project) => project.id === projectId) || mockProjects[0];
}

export function getTeamInitials(team = []) {
  return team.map((member) =>
    member
      .split(" ")
      .map((part) => part[0])
      .join("")
      .slice(0, 2)
      .toUpperCase()
  );
}

export default mockProjects;